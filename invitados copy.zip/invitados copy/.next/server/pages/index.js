"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "semantic-ui-react"
var external_semantic_ui_react_ = __webpack_require__(831);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/navbar.js



const Navbar = () => {
  const router = (0,router_.useRouter)();
  return /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Menu, {
    inverted: true,
    borderless: true,
    attached: true,
    children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Container, {
      children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Menu.Menu, {
        position: "right",
        children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Menu.Item, {
          children: /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Button, {
            primary: true,
            size: "large",
            color: "violet",
            onClick: () => router.push('/invitados'),
            children: "Invitados"
          })
        })
      })
    })
  });
};
;// CONCATENATED MODULE: ./src/components/aproval.js




const ApprovalCard = props => {
  const {
    0: approval,
    1: setApproval
  } = (0,external_react_.useState)(props.status);
  (0,external_react_.useEffect)(() => {
    setTimeout(() => {
      setApproval(false);
    }, 2000);
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Card, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Card.Content, {
      textAlign: "center",
      children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Card.Description, {
        children: "Mesa:"
      }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Card.Header, {
        children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
          children: props.table
        })
      })]
    })
  });
};
;// CONCATENATED MODULE: ./src/pages/index.js



 //import { Search } from 'components/search';




function Home({
  tasks
}) {
  const {
    0: invitado,
    1: setInvitado
  } = (0,external_react_.useState)({
    id: "",
    name: "",
    table: "",
    status: ""
  });
  const {
    0: input,
    1: setInput
  } = (0,external_react_.useState)("");
  const {
    0: list,
    1: setList
  } = (0,external_react_.useState)(false);
  const inputReference = (0,external_react_.useRef)(null);
  (0,external_react_.useEffect)(() => {
    inputReference.current.focus();
  }); //const [checkIn, setcheckIn] = useState(false)

  const updateInvitado = async () => {
    try {
      await fetch("http://localhost:3000/api/tasks", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(invitado)
      });
    } catch (err) {
      console.log("Valio dick", err);
    }
  };

  const handleChange = async e => {
    setInput(e.target.value);
    const result = tasks.find(task => task.name === e.target.value);

    if (result != undefined) {
      setInvitado({
        //id: result._id,
        name: result.name,
        table: result.table
      });
      setList(true);
      setInput("");
      await updateInvitado();
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Navbar, {}), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Header, {
      as: "h1",
      textAlign: "center",
      dividing: "true",
      children: "XVI"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Container, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Image, {
        src: "./inverted-dance.gif",
        size: "large",
        centered: true
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Card, {
        centered: true,
        children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Input, {
          ref: inputReference,
          onChange: handleChange,
          value: input
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_semantic_ui_react_.Card.Content, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Card.Header, {
            textAlign: "center",
            children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
              children: invitado.name
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(external_semantic_ui_react_.Transition, {
            visible: list,
            animation: "scale",
            duration: 1000,
            children: /*#__PURE__*/jsx_runtime_.jsx(ApprovalCard, {
              name: invitado.name,
              table: invitado.table,
              status: list
            })
          })]
        })]
      })]
    })]
  });
}
const getServerSideProps = async ctx => {
  const res = await fetch("http://localhost:3000/api/tasks");
  const tasks = await res.json();
  return {
    props: {
      tasks
    }
  };
};

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 831:
/***/ ((module) => {

module.exports = require("semantic-ui-react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(620));
module.exports = __webpack_exports__;

})();